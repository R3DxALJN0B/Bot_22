
import telebot
import requests
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("INTELX_API_KEY")
BASE_URL = "https://free.intelx.io/"

bot = telebot.TeleBot(os.getenv("TELEGRAM_BOT_TOKEN"))

def search_intelx(query):
    headers = {
        "x-key": API_KEY,
    }
    params = {
        "term": query,
        "maxresults": 5,
        "media": 0,
    }
    response = requests.get(BASE_URL + "api/?operation=search", headers=headers, params=params)
    results = response.json().get("records", [])
    output = []
    for record in results:
        content = record.get("content", "")
        if content:
            output.append(content.strip()[:500])
    return output if output else ["لم يتم العثور على تسريبات."]

@bot.message_handler(func=lambda m: True)
def handle_message(message):
    query = message.text.strip()
    bot.send_chat_action(message.chat.id, 'typing')
    results = search_intelx(query)
    for res in results:
        bot.send_message(message.chat.id, res)

bot.polling()
